import React from 'react'
import Reiw_tab from '../Reiw_tab/Reiw_tab'

function review_card() {
  return (
    <div className=' my-5 d100hv_color'>
     <div className="container  bg-white rounded">
        <Reiw_tab/>
     </div>
    </div>
  )
}

export default review_card
